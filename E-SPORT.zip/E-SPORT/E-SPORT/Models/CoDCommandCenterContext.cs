﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace E_SPORT.Models;

public partial class CoDCommandCenterContext : DbContext
{
    public CoDCommandCenterContext()
    {
    }

    public CoDCommandCenterContext(DbContextOptions<CoDCommandCenterContext> options)
        : base(options)
    {
    }

    public virtual DbSet<LeaderBoard> LeaderBoards { get; set; }

    public virtual DbSet<Team> Teams { get; set; }

    public virtual DbSet<User1> User1s { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=DESKTOP-IKNUD48;Initial Catalog=CoD_Command_Center; Encrypt=False; Integrated Security=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<LeaderBoard>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__LeaderBo__CB9A1CDF2F73D089");

            entity.ToTable("LeaderBoard");

            entity.Property(e => e.UserId)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("userID");
            entity.Property(e => e.KillCount).HasColumnName("killCount");
            entity.Property(e => e.Level).HasColumnName("level");
            entity.Property(e => e.UserName)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.HasOne(d => d.UserNameNavigation).WithMany(p => p.LeaderBoards)
                .HasForeignKey(d => d.UserName)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LeaderBoa__UserN__3C69FB99");
        });

        modelBuilder.Entity<Team>(entity =>
        {
            entity.HasKey(e => e.TeamId).HasName("PK__Team__5ED7534A717EA10A");

            entity.ToTable("Team");

            entity.Property(e => e.TeamId)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("teamID");
            entity.Property(e => e.Level).HasColumnName("level");
            entity.Property(e => e.NumTrophees).HasColumnName("numTrophees");
            entity.Property(e => e.Ranking).HasColumnName("ranking");
            entity.Property(e => e.Role)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("role");
            entity.Property(e => e.TeamName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("teamName");
            entity.Property(e => e.UserName)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.HasOne(d => d.UserNameNavigation).WithMany(p => p.Teams)
                .HasForeignKey(d => d.UserName)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Team__UserName__398D8EEE");
        });

        modelBuilder.Entity<User1>(entity =>
        {
            entity.HasKey(e => e.UserName).HasName("PK__User1__C9F28457F1FC49F3");

            entity.ToTable("User1");

            entity.Property(e => e.UserName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Badge)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("badge");
            entity.Property(e => e.EmailAddress)
                .HasMaxLength(40)
                .IsUnicode(false)
                .HasColumnName("emailAddress");
            entity.Property(e => e.FirstName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("firstName");
            entity.Property(e => e.KillCount).HasColumnName("killCount");
            entity.Property(e => e.KnockoutRatio)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("knockoutRatio");
            entity.Property(e => e.LastName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("lastName");
            entity.Property(e => e.Level).HasColumnName("level");
            entity.Property(e => e.NickName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("nickName");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
